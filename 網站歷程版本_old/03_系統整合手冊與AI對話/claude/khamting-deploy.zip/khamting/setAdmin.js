const admin=require('firebase-admin');
admin.initializeApp({credential:admin.credential.cert(require('./serviceAccountKey.json'))});
admin.auth().getUserByEmail('twvisa2009@gmail.com')
  .then(u=>admin.auth().setCustomUserClaims(u.uid,{admin:true}))
  .then(()=>{console.log('管理員權限設定完成，請登出再登入網站');process.exit()})
  .catch(e=>{console.log('失敗：',e.message);process.exit(1)});
